﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace OhmCalculator.Models
{
    public class OhmModel
    {
        public int Id { get; set; }
        public string RingColorBand1 { get; set; }
        public string RingColorBand2 { get; set; }
        public string RingColorBand3 { get; set; }
        public string RingColorBand4 { get; set; }

        public Nullable<int> SignificantFigNum { get; set; }
        public Nullable<double> Multiplier { get; set; }
        public Nullable<double> TolerancePer { get; set; }
        public List<OhmTableDetail> ColorOption1 { get; set; }
        public List<OhmTableDetail> ColorOption2 { get; set; }
        public List<OhmTableDetail> Multi { get; set; }
        public List<OhmTableDetail> Percentage { get; set; }

        public Nullable<double> Ohmnegresult { get; set; }
        public Nullable<double> Ohmpsvresult { get; set; }
    }
}