DROP TABLE ED279Prod.OhmTableDetails
Create Table ED279Prod.OhmTableDetails
(
Id int Identity(1,1) Primary Key, 
RingColorName Varchar(100),
SignificantFigNum int, 
Multiplier float,
TolerancePer float 
)


Insert into ED279Prod.OhmTableDetails
SELECT 'Pink',	Null,0.001, NULL
UNION 
SELECT 'Silver',NULL,0.01,10
UNION 
SELECT 'Gold',NULL,0.1,5
UNION 
SELECT 'Black',0,1,	NULL
UNION 
SELECT 'Brown',1,10,1
UNION 
SELECT 'Red',2,100,2
UNION 
SELECT 'Orange',3,1000,NUll
UNION 
SELECT 'Yellow',4,10000,5
UNION 
SELECT 'Green',5,100000,0.5
UNION 
SELECT 'Blue',6,1000000,0.25
UNION 
SELECT 'Violet',7,10000000,0.1
UNION 
SELECT 'Gray',8,100000000,0.05
UNION 
SELECT 'White',9,1000000000,NULL


--SELECT * FROM  ED279Prod.OhmTableDetails

Create Procedure ED279Prod.OhmTableCalc
@ColorOp1 Varchar(50), @ColorOp2 Varchar(50),  @ColorOp3 Varchar(50)
AS
BEGIN 

SELECT 


END 


