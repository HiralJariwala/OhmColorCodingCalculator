﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OhmCalculator.Models;


namespace OhmCalculator.Controllers
{
    public class HomeController : Controller , IOhm
    {
        public ActionResult Index()
        {

            OhmEntities context = new OhmEntities();
            OhmModel model = new OhmModel();
            model.ColorOption1 = context.OhmTableDetails.Where(r => r.SignificantFigNum != null).ToList();
            model.ColorOption2 = context.OhmTableDetails.Where(r => r.SignificantFigNum != null).ToList();
            model.Multi = context.OhmTableDetails.Where(r => r.Multiplier != null).ToList();
            model.Percentage = context.OhmTableDetails.Where(r => r.TolerancePer != null).ToList();

            return View(model);
        }

        [HttpPost]      
        public ActionResult CalculateOhmValue(OhmModel Model)
        {
            
            OhmEntities context = new OhmEntities();
            OhmModel m = new OhmModel();
            var Result = CalculateOhmValue(Model.RingColorBand1, Model.RingColorBand2, Model.RingColorBand3, Model.RingColorBand4);
            //var Result = context.OhmTableCalc(Model.RingColorBand1, Model.RingColorBand2, Model.RingColorBand3, Model.RingColorBand4).ToList();
            m.Ohmnegresult = Result.FirstOrDefault().Resivalue1;
            m.Ohmpsvresult = Result.FirstOrDefault().Resivalue2;
            return View(m);
        }
        public List<OhmTableCalc_Result1> CalculateOhmValue(string RingColorBand1, string RingColorBand2, string RingColorBand3, string RingColorBand4)
        {
            
            OhmEntities context = new OhmEntities();            
            var Result = context.OhmTableCalc(RingColorBand1, RingColorBand2, RingColorBand3, RingColorBand4).ToList() ;             
            return Result;
        }

    }
}