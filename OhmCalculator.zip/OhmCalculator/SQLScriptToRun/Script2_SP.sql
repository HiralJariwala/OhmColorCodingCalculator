Alter Procedure ED279Prod.OhmTableCalc
	@ColorOp1 Varchar(50), 
	@ColorOp2 Varchar(50),  
	@ColorOp3 Varchar(50), 
	@ColorOp4 Varchar(50)
AS
BEGIN 

SELECT 

		SigMultiValue - PercenValue Resivalue1,
		SigMultiValue + PercenValue Resivalue2


FROM (

			SELECT					
					SigNumResult, 
					Multiplier, 
					Percen, 
					SigNumResult * Multiplier  SigMultiValue, 
					SigNumResult * Multiplier * (Percen /100) PercenValue

					FROM (
					SELECT (SELECT SignificantFigNum FROM ED279Prod.OhmTableDetails WHERE RingColorName = @ColorOp1) SigNum1, 
						   (SELECT SignificantFigNum FROM ED279Prod.OhmTableDetails WHERE RingColorName = @ColorOp2) SigNum2,
						   (SELECT Convert(varchar(50),SignificantFigNum) FROM ED279Prod.OhmTableDetails WHERE RingColorName = @ColorOp1) +'' +(SELECT  Convert(varchar(50),SignificantFigNum) FROM ED279Prod.OhmTableDetails WHERE RingColorName = @ColorOp2) SigNumResult,
						   (SELECT Multiplier FROM ED279Prod.OhmTableDetails WHERE RingColorName = @ColorOp3) Multiplier, 
						   (SELECT TolerancePer FROM ED279Prod.OhmTableDetails WHERE RingColorName = @ColorOp4) Percen 
	   ) x
) Y

END 



EXEC ED279Prod.OhmTableCalc 'yellow','Red','Violet','blue'



SELECT * FROM ED279Prod.OhmTableDetails WHERE RingColorName = 'blue'